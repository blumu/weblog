(** Desicion of the size-change condition.

  @author William Blum
  @version 1.1
*)

exception Not_composible

let verbose = ref false;;

type ident = string
type sub_expr = int
type gb_element = Variable of int | Bullet
type scg_arclabel = ArrowDown | ArrowEqual
type ctlpt = int
type scg_arc = gb_element * scg_arclabel * gb_element
type scg = ctlpt * ctlpt * scg_arc list  * ctlpt list
type scgs_mat = (scg_arc list * ctlpt list ) list array array


  class virtual ['tnode] tprogram (v,(e:'tnode array)) = object(self)
    val mutable variables = v
    val mutable expr = e
			 
    method virtual string_of_ctlpt : ctlpt -> string
      
    (** [print_scg_arcs arcs] prints the list of arcs of a size_change graph. 
      @param arcs is the list of arcs to be printed
    *)
    method print_scg_arcs =
      let print_gbelement e = print_string ((function Bullet -> "*" | Variable(x) -> variables.(x) ) e) in
      let print_scg_arc (i,r,j) =
	print_gbelement i;
	print_string ((function  ArrowEqual -> "=" | ArrowDown -> ">") r);
	print_gbelement j;
      in
	Tools.print_list print_scg_arc
	  
	  
    (** [print_scgraph scg] prints the size-change graphs scg. *)
    method print_scgraph (e1,e2,arcs,cpoints) = 
      let print_cpt pt = print_string (self#string_of_ctlpt pt)
      in
      print_cpt e1; print_string "->*"; print_cpt e2;
      print_string ",";  self#print_scg_arcs arcs;
      Tools.print_list print_cpt cpoints;
          
    (** [print_scgraphs lstscg] prints the list lstscg of size-change graphs.
      program numbered expression *)
    method print_scgraphs lscg =
      List.iter (fun g -> self#print_scgraph g; print_newline() ) lscg;
      print_newline()

							     
    (** [eq_vertex v1 v2] returns true iff the vertices v1 and v2 are equivalent
      (i.e they represent the same variable or they are both equal to Bullet ) *)
    method eq_vertex v1 v2 = match v1,v2 with
	Bullet,Bullet -> true
      | Variable(i),Variable(j) when i = j -> true
      | _ -> false
	  
    (** [eq_arc a1 a2] returns true iff arcs a1 and a2 are equivalent
      (i.e they have the same label and there are pointing to equivalent vertices) *)
    method eq_arc (a,u,b) (c,v,d) = (u=v) && (self#eq_vertex a c) && (self#eq_vertex b d)
				      
    (** [eq_arcs arcs1 arcs2] returns true iff the lists arcs1 and arcs2 contains the same set of arcs 
    *)
    method eq_arcs = Tools.listset_equal self#eq_arc
		       

    (** Composition of two size-change graphs (see definition 1 of Jones's paper)
      [scg_compose g1 g2]
      @param g1 first graph arcs list
      @param g2 second graph arcs list
      @return the arcs list in the composed graph g1;g2
    *)
    method scg_compose arcs1 arcs2 =
      (* the 2 graphs need to be composible *)
      let rec find_desc_transitions = function
	  (x,ArrowDown,y) ->
	    Tools.map_filter (fun (_,_,z) -> (x,ArrowDown,z)) (fun (u,_,_)-> u=y) arcs2
	| (x,ArrowEqual,y) ->
	    Tools.map_filter (fun (_,_,z) -> (x,ArrowDown,z)) (fun (u,r,_)-> u=y && r=ArrowDown) arcs2
      and find_equ_transitions = function
	  (x,ArrowEqual,y) ->
	    Tools.map_filter (fun (_,_,z) -> (x,ArrowEqual,z)) (fun (u,r,_)-> u=y && r=ArrowEqual) arcs2	      
	| _ -> []
      in
      let x_des_z = Tools.flatten_map find_desc_transitions arcs1
      and x_equ_z = Tools.flatten_map find_equ_transitions arcs1
      in
	x_des_z@
	(List.filter
	   (function x,_,z -> not (List.mem (x,ArrowDown,z) x_des_z))
	   x_equ_z)
	  
    (** [composition_closure scgmat] finds the closure by composition
      of the set of size-change graphs stored in the matrix scgmat.
      @param scgmat is a matrix NxN where N is the number of subexpressions in P.
    *)
    method composition_closure scgmat =
      let n = Array.length scgmat
      in
      let contains_scg a1 =
	List.exists (function (a2,_) -> self#eq_arcs a1 a2 )
      in
      let modif = ref true
      and nb_added = ref 0
      and nb_iter = ref 0 in
	while !modif do
	  incr(nb_iter);
	  Debug.set_int 1 !nb_iter;
	  modif := false;
	  for i = 0 to n-1 do
	    for j = 0 to n-1 do
	      for k = 0 to n-1 do
		Debug.set_int 2 i;
		Debug.set_int 3 j;
		Debug.set_int 4 k;
		if scgmat.(j).(k) <> [] && scgmat.(i).(j) <> [] then
		  let compose_and_add (g1_arcs,g1_pts) (g2_arcs,g2_pts) =
		    let g1g2_arcs = self#scg_compose g1_arcs g2_arcs
		    in
		      if not (contains_scg g1g2_arcs scgmat.(i).(k)) then 
			begin
			  let g1g2_pts = g1_pts@(j::g2_pts) in
			    if !verbose then
			      begin
				print_string "NEW ";
				
				self#print_scgraph (i,k,g1g2_arcs,g1g2_pts);  print_string "   =   ";
				self#print_scgraph (i,j,g1_arcs,g1_pts);  print_string "   ;   ";
				self#print_scgraph (j,k,g2_arcs,g2_pts);
				print_newline();
			      end;
			    incr(nb_added);
			    Debug.set_int 0 !nb_added;
			    modif := true;
			    scgmat.(i).(k) <- (g1g2_arcs,g1g2_pts)::scgmat.(i).(k);
			end
		  in
		    List.iter (function g1 ->
				 List.iter (function g2 -> 
					      compose_and_add g1 g2
					   )
				 (List.rev scgmat.(j).(k))
			      )
		      (List.rev scgmat.(i).(j))
		      
		      
		done;
	      done;
	    done;
	done;
	  
    (** [is_loop scg] returns true iff the size-change graph scg
      describes a loop (i.e. the two graph basis are identical and G;G=G).
    *)
    method is_loop (_,_,arcs,_) =
      let comp = self#scg_compose arcs arcs in
	self#eq_arcs comp arcs
	 
	 
    (** [is_descending scg] returns true if scg contains an arc of type x>x
    *)
    method is_descending (_,_,edges,_) =
      let is_desc_arc (u,a,v) = match u,a,v with
	  Variable(x),ArrowDown,Variable(y) when x=y -> true
	| _ -> false
      in
	List.exists is_desc_arc edges
	      
	      
    (** This function decides the size-change termination property. 
      In the call [is_sct mat_scgs]
      @param safe_scgs is a list containing size-change graphs safely describing P
      @return (b,dloops) where b = true iff P is size-change terminating and dloops is the list of all size-change graphs
      describing descending loops if p is sct or non descending loops if p is not sct *)
    method is_sct mat_scgs =

      let list_from_matrix_diagonal mat =
	let n = Array.length mat in
	let lst_closure = ref [] in
	for i = 0 to n-1 do
	  lst_closure := !lst_closure @ 
	  (List.map
	     (function (arcs,pts) -> i,i,arcs,pts )
	     mat.(i).(i))
	done;
	!lst_closure
      in
      
      (* find the closure by composition of the set of size-change graphs. *)
      print_string "Computation of the closure by graph composition...\n";
      flush stdout;
      self#composition_closure mat_scgs;

      print_string "Loops extraction...\n";
      flush stdout;
      let lst_closure = list_from_matrix_diagonal mat_scgs
      in

      (*  return the list of size-change graphs describing loops *)
      print_string "Loops analysis...\n";
      flush stdout;
      let loops = List.filter self#is_loop lst_closure
      in
	
      (* separate the descending and non-descending loops *)
      let des_loops, nondes_loops = List.partition self#is_descending loops in
	if nondes_loops=[] then
	  (* p is sct: return all the loops (which are all descending) *)
	  true,des_loops
	else
	  (* p is not sct: return the critical loops (not descending loops) *)
	  false,nondes_loops
  end


  module CtlPtSet = Set.Make(struct type t = int let compare = Pervasives.compare end)

  class virtual ['tnode, 'jftype, 'jfgen] tgrgen_program ((v:ident array),(e:'tnode array),fv) = 
  object(self)
    inherit ['tnode] tprogram (v,e) as super

    (** array containing the list of free variables for every 
      control point *)
    val mutable freevars = fv

    (** matrix of list of judgement forms 
      jf_array.(i).(j) contains the list of judgement forms
      relating subexpression i to subexpression j
    *)
    val jf_array =
      let n = Array.length e in
	Array.make_matrix n n ([]:('jftype * 'jfgen) list)

    (** number of jforms contained in the lists of the matrix jf_array *)
    val nb_jf = ref 0
			     
    (** [free_variables pt]
      @return a list containing the indices of the free variables
      at the control point pt.
    *)
    method free_variables pt =
      CtlPtSet.elements (freevars.(pt))

    method virtual string_of_jftype : 'jftype -> string

    method virtual eq_gen : 'jfgen -> 'jfgen -> bool
    method virtual print_gen : 'jfgen -> unit
    method virtual is_closed : unit -> bool


    (** [creat_jf] adds a new jf to the array of jfs *)
    (* TODO:
       - change the type of the elements of jf_array from List to Map.
       - when adding a new jf,
       if there are already jfs of the same type for the same program points
       then we should remove all such jf which scg is a superset of the new jf scg
       and add the new jf only no other jf has a scg included in the new jf's scg.
    *)    
    method create_jf njf_type njf_p1 njf_p2 njf_gen =
      (* Returns true if a given judgement form and the new jf are the same *)
      let eq_njf (t,gen) = (t=njf_type) && (self#eq_gen gen njf_gen)
      in
	
	(* check that the new judgment form is not already present in the matrix *)
	if not (List.exists eq_njf jf_array.(njf_p1).(njf_p2)) then
	  begin
	    if !verbose then self#print_jf njf_p1 njf_p2 njf_type njf_gen;
	    jf_array.(njf_p1).(njf_p2) <- (njf_type,njf_gen)::jf_array.(njf_p1).(njf_p2);
	    incr (nb_jf);
	    if not !verbose then
	      begin
		Debug.set_int 0 !nb_jf;
		(*
		  print_int !nb_jf;
		  print_string "\r";*)
	      end
	  end

    
    (** [print_jf p1 p2 t gen] prints the judgement form relating
      program points [p1] and [p2] by the relation [t] and with the
      generated component [gen] *)
    method print_jf p1 p2 (o:'jftype) gen = 
      print_string
	((self#string_of_ctlpt p1)
	 ^ (self#string_of_jftype o)
	 ^ (self#string_of_ctlpt p2)
	 ^ ",");
      self#print_gen gen;
      print_string "\n";

    (** [gr_value e] builds the size-change graph id=_e used in the rule (ValueG)
      @param e is the program subexpression index number
    *)
    method gr_id_eq e = 
      let fv = self#free_variables e
      and idarrow x = Variable(x), ArrowEqual, Variable(x)
      in (Bullet,ArrowEqual,Bullet)::(List.map idarrow fv)
    

    (** [gr_id_eq_subxx x e] computes the size-change graph id=_e \ \{ x = x \}
      @param x is the variable index
      @param e is the program subexpression index number
    *)
    method gr_id_eq_subxx x e =
      let fv = CtlPtSet.elements (CtlPtSet.remove x freevars.(e)) in
      let idarrow v = Variable(v), ArrowEqual, Variable(v)
      in
	(Bullet,ArrowEqual,Bullet)::(List.map idarrow fv)

    (** [gr_id_des e] computes the size-change graph id|_e used in the rules (OperandG) and (OperatorG)
      @param e is the program subexpression index number
    *)
    method gr_id_des e =
      let fv = self#free_variables e in
      let idarrow x = Variable(x), ArrowEqual, Variable(x)
      in (Bullet, ArrowDown, Bullet)::(List.map idarrow fv)

    (** [gr_idv e] computes the size-change graph idv_e
      @param e is the program subexpression index number
    *)
    method gr_idv e =
      let fv = self#free_variables e in
      let idarrow x = Variable(x), ArrowEqual, Variable(x)
      in List.map idarrow fv
    
    (** [gr_idv_subxx e] computes the size-change graph idv_e \ \{ x = x \}
      @param x is the variable index
      @param e is the program subexpression index number
    *)
    method gr_idv_subxx x e =
      let fv = CtlPtSet.elements (CtlPtSet.remove x freevars.(e)) in
      let idarrow v = Variable(v), ArrowEqual, Variable(v)
      in List.map idarrow fv


    (** Construct the size-change graph corresponding to the rule (VarG)
      in Neil D. Jones paper.
      
      In the call [gr_var x v2] :
      @param x is the index of variable x in the array [variables]
      @param v2 is the program subexpression index number for v2 in (VarG)
    *)
    method gr_var x v2  =
      let fv = self#free_variables v2
      and xy_arrow y = Variable(x), ArrowDown, Variable(y)
      in	
	(Variable(x), ArrowEqual, Bullet)::(List.map xy_arrow fv)

    (** [gr_var0 x] : build the ground type graph for the rule (VarAG)
      @param x is the index of variable x in the array [variables]
    *)
    method gr_var0 x =
      [(Variable(x), ArrowEqual, Bullet); (Bullet, ArrowEqual, Bullet)]
	  
	  
    (** [gr_succ] computes the size-change graph generated in the (SuccG) rule
      @param arcs is the list of arcs of the size-change graph G in the premise of (SuccG)
    *)
    method gr_succ (arcs:scg_arc list) =
      (Bullet, ArrowEqual, Bullet)::
      (Tools.map_filter (fun (_,_,x) -> Bullet,ArrowDown,x)
	 (fun (b,_,x) -> b=Bullet && x<>Bullet) arcs)

    (** [gr_pred g] computes the size-change graph generated in the (PredG) rule
      @param arcs is the list of arcs of the size-change graph G in the premise of (PredG)
    *)
    method gr_pred (arcs:scg_arc list) =
      (Bullet, ArrowEqual, Bullet)::
      (Tools.map_filter (fun (x,_,_) -> x,ArrowDown,Bullet)
	 (fun (x,_,b) -> b=Bullet && x<>Bullet) arcs)


    (** Construct the size-change graph corresponding to the rule (CallG)
      in Neil D. Jones paper:
        G_1^\{-*\} U G^\{*->x\}_2     
      In the call [gr_call x g1 g2] :
      @param x is the index of variable x in the array [variables]
      @param g1 is the list of arcs of the size-change graph G_1 used in (CallG)
      @param g2 is the list of arcs ot the size-change graph G_2 used in (CallG)
    *)
    method gr_call x g1 g2  =
      let arcs1 =
	(Tools.map_filter (fun (_,_,z) -> Bullet,ArrowDown,z)
	   (fun (b,_,z) -> b=Bullet && z<>Bullet) g1)
	@ (List.filter (fun (y,_,z) -> (y<>Bullet && z<>Bullet) ) g1)
	  
      and arcs2 =
	(Tools.map_filter (fun (_,_,_) -> (Bullet,ArrowDown,Variable(x))) 
	   (fun (b1,_,b2) -> b1=Bullet && b2=Bullet) g2)
	@ (Tools.map_filter (fun (y,r,_) -> y,r,Variable(x))
             (fun (y,_,b) -> y<>Bullet && b=Bullet) g2)
      in  
	arcs1@arcs2

    (** [gr_call0 x g1 g2] : build the ground type graph for the rule (CallG)
      @param x is the index of variable x in the array [variables]
      @param g1 is the list of arcs of the size-change graph G_1 used in (CallG)
      @param g2 is the list of arcs ot the size-change graph G_2 used in (CallG)
    *)
    method gr_call0 x g1 g2  =
      let arcs1 = List.filter (fun (y,_,z) -> (y<>Bullet && z<>Bullet) ) g1
	  
      and arcs2 = Tools.map_filter (fun (y,r,_) -> y,r,Variable(x))
		    (fun (y,_,b) -> y<>Bullet && b=Bullet) g2
      in  
	(Bullet,ArrowEqual,Bullet)::(arcs1@arcs2)
 

    (** [gr_local x g1 e g2] : build the high-order graph for the rule (LocalG)
      @param x is the index of variable x in the array [variables]
      @param g1 is the list of arcs of the size-change graph G_1 used in (LocalG)
      @param e is the subexpression index number
      @param g2 is the list of arcs ot the size-change graph G_2 used in (LocalG)
    *)
    method gr_local x g1 (e:ctlpt) g2  =
	self#scg_compose (self#gr_call x (self#gr_id_eq_subxx x e) g1) g2


    (** [gr_local0 x g1 e g2] : build the ground type graph for the rule (LocalG)
      @param x is the index of variable x in the array [variables]
      @param g1 is the list of arcs of the size-change graph G_1 used in (LocalG)
      @param e is the subexpression index number
      @param g2 is the list of arcs ot the size-change graph G_2 used in (LocalG)
    *)
    method gr_local0 x g1 (e:ctlpt) g2  =
      self#scg_compose (self#gr_call0 x (self#gr_id_eq_subxx x e) g1) g2

  end
