(** Tools for list manipulation.
  @author William Blum
  @version 1.o
*)

(** [listsize_fixedpont f l]
  Apply f to the list l and repeat the process on the result until the list returned by f is of the same size
  as the list given as its input.
  [f] needs to be a monotone to guarantee termination.
 *)
let rec listsize_fixedpoint f l =
  let n = List.length l in
  let new_list = f l in
  let new_n = List.length new_list in
    if new_n = n then l
    else listsize_fixedpoint f new_list
;;

(** [list_remove_first pred l] returns the list obtained after removing
   the first element e in l for which (f e) is true
    @raise Not_found if there is no element such that f e = true
*)
let rec list_remove_first pred = function
    [] -> raise Not_found;
  | t::q when pred t -> q
  | t::q -> t::(list_remove_first pred q)
;;


(** [listset_equal equ_fonc l1 l2] returns true if l1 and l2 contain the same 
  set of elements.  [equ_fonc] is the comparison function used to compare elements of the two lists.
*)
let rec listset_equal equ_fonc l1 l2 = match l1,l2 with
    [],[] -> true
  | t1::q1, _ ->
      (try 
	listset_equal equ_fonc q1 (list_remove_first (equ_fonc t1) l2)
      with Not_found -> false)
  | _,_ -> false
;;



(** [print_list f l] prints a list of elements. [f] is the function called to print an element of the list. *)
let print_list f l =
  print_string "[";
  (match l with
      [] -> ()
    | [t] -> f t
    | t::q -> (f t); List.iter (function x-> print_string ", "; f x ) q
  );
  print_string "]";  
;;

(** [sub_list n l] returns the list of the n first elements of the list l *)
let rec sub_list n l = match l,n with
    _,0 -> []
  |t::q,n -> t::(sub_list (n-1) q)
  |_ -> raise Not_found
;;


(** [flatten_map f [a1; ...; an]] applies function [f] to [a1, ..., an] and and builds the list [(f a1)@(f a2)@...@(f an)].
    The result is the same as [flatten (map f [a1; ...; an])] *)
let rec flatten_map f l = match l with
    [] -> []
  | t::q -> (f t)@(flatten_map f q)
;;

(** [map_filter f cond l] is equivalent to [List.map f (List.filter cond l)] *)
let rec map_filter f cond = function 
    [] -> []
  | t::q when cond t -> (f t)::(map_filter f cond q)
  | t::q -> map_filter f cond q
;;    
  
