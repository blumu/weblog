(** Implementation of the Size-change principle for the untyped lambda calculus.
  see "Termination Analysis of the Untyped lambda-calculus", Neil D. Jones

  @author William Blum
*)
open Sct;;


(** Type for untyped lambda expressions *)
type lambda_expr =
    Var of Sct.ident 
  | Abstr of Sct.ident * lambda_expr
  | Appl of lambda_expr * lambda_expr;;

(** Type used for subexpression nodes *)
type lmd_node =
    VarN of int
      (* Suppose that variable x is declared in node number i then
	 then VarN(i) represents the lambda expression x *)
  | AbstrN of int * Sct.sub_expr
      (* Suppose that variable x is declared in node number i then
	 and the node j corresponds to the subexpression e
	 then AbstrN(i,j) represents the lambda expression 'lambda x.e' *)
  | ApplN of Sct.sub_expr * Sct.sub_expr
      (* Suppose that the node i corresponds to the subexpression e1
	 and the node j corresponds to the subexpression e2
	 then ApplN(i,j) represents the lambda expression e1@e2 *)

(** Type used for control points *)
type lmd_cpt = Sct.sub_expr

(** type for the judgment form type (operator, operand, call or evaluation) *)
type lmd_jftype = Operator | Operand | FuncApp | Evaluation;;

(** type for the generated component in judgment forms *)
type lmd_jfgen = scg_arc list

(** type for a judgment form *)
type lmd_jf = lmd_jftype * lmd_jfgen


class tlmd_program (v,e,fv) = 
object(self)
    inherit [lmd_node, lmd_jftype, lmd_jfgen] tgrgen_program (v,e,fv) as super
   
    (** active_expr.(i) = true only when the subexpression i has been activated
       (there is a call sequence from P to subexpression i)
    *)
    val activ_expr =
      let n = Array.length e in
	Array.make n false

    
    initializer 
      (* Activate the expression of P itself! *)
      activ_expr.(0) <- true;

  
    (** convert a judgement form type into a string *)	     
    method string_of_jftype =
      function FuncApp -> "-c->" | Operator -> "-r->" | Operand -> "-d->" | Evaluation -> "||"

    (** convert a control point into a string *)	     
    method string_of_ctlpt i =
      match expr.(i) with
	  VarN(x) -> variables.(x)^":"^(string_of_int i)
	| _ -> string_of_int i

    (** [is_closed() ]
      @return true iff the lambda expression of the program is closed (contains no free variable)
    *)
    method is_closed () = 
      CtlPtSet.is_empty fv.(0)

    method eq_gen = self#eq_arcs
    method print_gen = super#print_scg_arcs

    (** Constructs the approximation size change graphs by applying
      exhaustively the approximate judgment form rules defined in
      Definition 17 of Jones's paper.
      @return a matrix where each element .(i).(j) contain
      the list of judgment forms relating program point i to
      program point j.
    *)
    method find_approx_jforms () = 
      let n = Array.length expr in
	
      (* Apply the function f to all the subexpression indexes corresponding to
	 a free occurence of the variable x in subexpression e.
      *)
      let rec do_foreach_freeoccurence f x e =
	match expr.(e) with
	  | VarN(y) when x=y -> f e

	  | AbstrN(y,e0) when x <> y ->
	      do_foreach_freeoccurence f x e0

	  | VarN(_) | AbstrN(_,_) ->
	      ();

	  | ApplN(e1,e2) ->
	      do_foreach_freeoccurence f x e1;
	      do_foreach_freeoccurence f x e2
      in

      (* [valueAG se] applies the rules (ValueAG)
	 to the expression se and its subexpressions.
	 (se is the expression on the left-most component in the new judgment form) *)
      let rec valueAG (se:Sct.sub_expr) =
	match expr.(se) with
	    AbstrN(x,e) ->
	      self#create_jf Evaluation se se (self#gr_id_eq se);
	      valueAG e;
	  | ApplN(e1,e2) -> valueAG e1; valueAG e2;
	  | _ -> ()
      in
	
      (* [applyAG] applies the rule (ApplyAG) as many times as possible *)
      let rec applyAG()  = 
	let foreach_fst_premise e1e2 e1 e2 eprime jf =
	  match jf with
	      FuncApp, gprime ->
		(* find the second premise *)
		for v = 0 to n-1 do
		  let lst_snd_premises = 
		    Tools.map_filter
		      (function _,g -> g)
		      (function (o,_) -> o = Evaluation)
		      jf_array.(eprime).(v)
		  in
		  let build_conclusion_jf g =
		    let arcs_comp = self#scg_compose gprime g
		    in
		      self#create_jf Evaluation e1e2 v arcs_comp
		  in
		    List.iter build_conclusion_jf lst_snd_premises
		done;
	    |_ -> ()
	in     
	  for e1e2 = 0 to n-1 do
	    match expr.(e1e2) with
		ApplN(e1,e2) ->
		  for eprime = 0 to n-1 do
		    List.iter (foreach_fst_premise e1e2 e1 e2 eprime) jf_array.(e1e2).(eprime)
		  done;
	      | _ -> ()
	  done;

      (* [operatorOperandAG se] applies the rules (OperatorAG) and (OperandAG)
	 as many times as possible starting on subexpression e.
	 (se is the expression on the left-most component in the new judgment form) *)
      and operatorOperandAG (se:Sct.sub_expr) =
	match expr.(se) with
	  | ApplN(e1,e2) ->
	      self#create_jf Operator se e1 (self#gr_id_des e1);
	      activ_expr.(e1) <- true;
	      self#create_jf Operand se e2 (self#gr_id_des e2);	      
	      activ_expr.(e2) <- true;

	      operatorOperandAG e1;
	      operatorOperandAG e2;
	  | _ -> ()

      (* [callAG] applies the rule (CallAG) *)
      and callAG() =
	(* We apply the rule on expressions of type e1@e2 such that there is
	   a jf of the form:
           e -c-> e1@e2
	   Applying the (CallAG) rule will then produce a jf of the form:
	   e1@e2 -c-> e0
	*)
	
	(* Look for jf of type "e -> e1@e2,G" *)
	for e1e2 = 0 to n-1 do
	  (* we are only interested in expression of type e1@e2 
	     which are activated (i.e. there is sequence of calls
	     from P to e1@e2 *)
	  match expr.(e1e2) with
	      ApplN(e1,e2) when activ_expr.(e1e2) ->
		(* for each evaluation of e2 *)
		for v2 = 0 to n-1 do
		  List.iter
		    (function
			 Evaluation,g2 ->
			   (* for each evaluation of e1 *)
			   for i = 0 to n-1 do
			     Debug.set_int 1 e1e2;
			     Debug.set_int 2 v2;
			     Debug.set_int 3 i;
			     
			     match expr.(i) with
				 AbstrN(x,e0) ->
				   List.iter
				   (function Evaluation,g1 ->
				      self#create_jf FuncApp e1e2 e0
				      (self#gr_call x g1 g2);
				      activ_expr.(e0) <- true;
				      operatorOperandAG e0;
				      | _ -> ()
				   )
				   jf_array.(e1).(i);			 
			       | _ -> ()
			   done
		       | _ -> ()
		    )		
      		    jf_array.(e2).(v2)
		done;
	    | _ -> ()
	done;
	  
      (* [varAG] Applies the rule (VarAG) *)
      and varAG() = 
	(* Look for P sub-expressions of type e1@e2 *)
	for e1e2 = 0 to n-1 do
	  match expr.(e1e2) with
	      ApplN(e1,e2) -> 
		(* for each evaluation of e2 *)
		for v2 = 0 to n-1 do
		  List.iter
		    (function
			 Evaluation,g2 ->
			   (* for each evaluation of e1 *)
			   for i = 0 to n-1 do
			     match expr.(i) with
				 AbstrN(x,e0) ->
				   List.iter
				   (function
					Evaluation,g1 ->
					  do_foreach_freeoccurence 
					  (function xi -> self#create_jf Evaluation xi v2 (self#gr_var x v2) )
					  x e0
				      | _ -> ()
				   )
				   jf_array.(e1).(i)
			       | _ -> ()
			   done
		       | _ -> ()
		    )		
      		    jf_array.(e2).(v2)
		done;
	    | _ -> ()
	done
      in
      let last_nb_jf = ref 0 in
      (* Apply all the rules until no new judgment form is found *)
	valueAG 0;
	operatorOperandAG 0;
	while !nb_jf > !last_nb_jf do
	  if !Sct.verbose then
	    begin
	      print_string "\n***** ";
	      print_int !nb_jf;
	      print_string " jfs\n";
	    end;
	  (* exhaustive search step *)
	  last_nb_jf := !nb_jf;
	  callAG();
	  applyAG();
	  varAG();
	done;
	print_string "\nNumber of jf:";
	print_int !nb_jf;
	print_string "\n";
    
    (** Build the set absint(P) defined in theorem 3 of Neil D. Jones's paper.
      This set of size_change graphs is safe for P. *)
    method build_safe_scg () :scgs_mat =
      self#find_approx_jforms ();
      
      print_string "Preparing for the closure computation...\n";
      flush stdout;
      let n = Array.length expr in
      let mat_scgs = Array.make_matrix n n [] in
	for i = 0 to n-1 do
	  for j = 0 to n-1 do
	    mat_scgs.(i).(j) <-
	      Tools.map_filter
		(function (o,arcs) -> arcs,[] )
		(function d,_ -> d<>Evaluation) 
		jf_array.(i).(j)
	  done;
	done;
	mat_scgs
	  

    (** convert the program expression into a xypic 
      latex figure representing the abstract tree
      @param noheaders if true then the document headers are not generated
    *)
    method to_latex noheaders =
      
      (* compute the width of the subtree of a subexpression *)
      let rec width i = match expr.(i) with
	  VarN(_) -> 1
	| ApplN(e1,e2) -> 1 + (width e1) + (width e2)
	| AbstrN(_,e) -> width e
	    
      and right_width i = match expr.(i) with
	  ApplN(e1,e2) -> width e2
	| AbstrN(_,e) -> right_width e
	| _ -> 0
	    
      and left_width i = match expr.(i) with
	  ApplN(e1,e2) -> width e1
	| AbstrN(_,e) -> left_width e
	| _ -> 0
      in
	
      (* breath first browsing of the expression 
	 sel is the sub expression list *)
      let print_node curpos (se,left) =
	for i = 1 to left-curpos do
	  print_string "*{}& "
	done;
	( match expr.(se) with
	      VarN(x) ->
		print_string (variables.(x)^" &");
	    |ApplN(e1,e2) ->
	       let lwe2 = left_width e2
	       and rwe1 = right_width e1 in
		 
	       let arrow_l = String.make (1+rwe1) 'l'
	       and arrow_r = String.make (1+lwe2) 'r'
	       in
		 print_string (" @ \\ar[d"^arrow_l^"]_>{");
		 print_int e1;
		 print_string ("} \\ar[d"^arrow_r^"]_>{");
		 print_int e2;
		 print_string "} &";
	    |AbstrN(x,e) -> 
	       print_string ("\\lambda "^variables.(x)^" \\ar[d]_>{");
		print_int e;
		print_string "} & ";
	);
	left+1
      in
      let rec nextlevel = function
	  [] -> []
	| (se,l)::q ->
	    match expr.(se) with
		ApplN(e1,e2) -> let lwe2 = left_width e2
				and rwe1 = right_width e1 in
		  [(e1,l-rwe1-1);(e2,l+lwe2+1)]@(nextlevel q)
	      | AbstrN(x,e) -> 
		  (e,l)::(nextlevel q)
	      | _ -> nextlevel q
      in
      let rec breadfirstbrowse level =
	(* print a level of the tree *)
	let _ = List.fold_left print_node 0 level in
	  
	(* compute the next level and print it if it is not empty *)
	let nlevel = nextlevel level in
	  if nlevel <> [] then
	    begin
	      print_string "*{} \\\\ \n";
	      breadfirstbrowse nlevel;
	    end
	  else
	    print_string "*{}\n";
      in
	(* covert a lambda expreesion into latex code *)
      let rec to_latex i = match expr.(i) with
	  VarN(x) -> print_string (variables.(x));
	| ApplN(e1,e2) -> to_latex_subexpr e1; print_string "\\ "; to_latex_subexpr e2;
	| AbstrN(x,e) -> print_string "\\lambda "; print_string (variables.(x)); print_string "\\cdot "; to_latex e

      and to_latex_subexpr i = match expr.(i) with
	  VarN(_) -> to_latex i;
	| e -> print_string "("; to_latex i; print_string ")"
      in
	
	if not noheaders then
	  begin
	    print_string "\n\\documentclass{article}\n";
	    print_string "\\usepackage{lscape}\n";
	    print_string "\\input xy\n";
	    print_string "\\xyoption{all}\n";
	    print_string "\\begin{document}\n";
	    
	    print_string "\\begin{landscape}\n";

	    print_string 
	      ("\\begin{table}[ht]\n \\centering \n"
	       ^"\\entrymodifiers={++[o][F-]}\n"
	       ^"\\SelectTips{cm}{}\n"
	       ^"\\resizebox{20cm}{!}{\n");
	    
	    print_string "$";
	    to_latex 0;
	    print_string "$\n";
	    
	    print_string "\\entrymodifiers={++[o][F-]}\n";
	    print_string "\\SelectTips{cm}{}\n";
	  end;

	print_string "$\\xymatrix @-1pc {\n";
	breadfirstbrowse [0,left_width 0];
	print_string "}$\n";

	if not noheaders then
	  begin
	    print_string "} \\end{table}\n";
	    print_string "\\end{landscape}\n";
	    print_string "\\end{document}\n";
	  end
      
end







(** [variables_in e] returns the set containing all the variables appearing in the lambda expression e
*)
let variables_in e =
  let module StringSet = Set.Make(struct type t = string let compare = Pervasives.compare end)
  in    
  let rec aux = function
      Var(x) -> StringSet.singleton x
    | Abstr(x,e) -> StringSet.add x (aux e)
    | Appl(e1,e2) -> StringSet.union (aux e1) (aux e2)
  in
    StringSet.elements (aux e)
;;

(**  [nb_nodes e] returns the number of nodes in the tree representing the lambda expression e *)
let rec nb_nodes e = match e with
    Var(x) -> 1
  | Abstr(x,q) -> 1 + (nb_nodes q)
  | Appl(e1,e2) -> 1 + (nb_nodes e1) + (nb_nodes e2)
;;

(** [program_of_lambdaexpr e] builds the program data structure from the lambda expression [e]. *)
let program_of_lambdaexpr e =
  (* array containing the variables identifier *)
  let var_array = Array.of_list (variables_in e) in

  (* number of variables *)
  let nvar = Array.length var_array in
    
  (* number of nodes in the tree representing the expression *) 
  let nnodes = nb_nodes e in
    
  (* allocate an array for storing all the nodes of the lambda expression *)
  let subexpr_array = Array.make nnodes (VarN(-1)) in

  (* allocate an array for storing the set of free variables *)
  let fv_array = Array.make nnodes (CtlPtSet.empty) in
    

  (* get the variable number from its identifier. *)
  let vardecl_number x =
    let v = ref 0 and found = ref false in
      while (not !found) && !v <nvar do
	if var_array.(!v) = x then
	  found := true
	else
	  incr(v);
      done;
      if not !found then
	failwith "bug in program_of_lambdaexpr (variable not found)!"
      else
	!v
  in
    
  let rec assign n e = match e with
      Var(x) -> 
	let varnum = vardecl_number x in
	  fv_array.(n) <- CtlPtSet.singleton varnum;
	  subexpr_array.(n) <- VarN(varnum);
	  n+1
    | Abstr(x,f) ->
	let varnum = vardecl_number x in
	let p = assign (n+1) f in
	  fv_array.(n) <- CtlPtSet.diff fv_array.(n+1) (CtlPtSet.singleton varnum);
	  subexpr_array.(n) <- AbstrN(varnum,n+1); p
    | Appl(e1,e2) ->
	let p = assign (n+1) e1 in
	let q = assign p e2 in
	  fv_array.(n) <- CtlPtSet.union fv_array.(n+1) fv_array.(p);
	  subexpr_array.(n) <- ApplN(n+1,p); q
  in
    (* start the numbering of the nodes from 0 *)
    let _ = assign 0 e in
      (* create the program object *)
      new tlmd_program( var_array, subexpr_array, fv_array )
;;



(* ************************************************************** *)
(* Printing functions                                             *)

(** Print a lambda expression *)
let rec print_lambda = function
    Var(x) -> print_string x;
  |Appl(Appl(e1,e2),e3) -> print_lambda (Appl(e1,e2));
      print_string " "; print_in_bracket e3;
  |Appl(e1,e2) -> print_in_bracket e1; print_string " "; print_in_bracket e2;
  |Abstr(x,e) -> print_string "lambda "; print_string x; print_string "."; print_lambda e
      
and print_in_bracket = function
    Var(x) -> print_string x;
  | e -> print_string "("; print_lambda e; print_string ")";
;;
