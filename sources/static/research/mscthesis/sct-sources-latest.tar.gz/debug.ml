(*  Debugging thread functions.
    
    @author William Blum
*)

let max_int_display = 10;;

let debug_message = ref "";;
let debug_int = Array.make max_int_display 0;;

let set_int i n = debug_int.(i mod max_int_display) <- n;;

let debug_thread p =
    print_string "Debugging thread launched!\n";

    while true do   
      print_string "d> ";
      flush stdout;
      let input = input_line stdin in
	if input = "exit" then
	  exit 1
	else
	  begin
	    print_int debug_int.(0); print_string ":";
	    print_int debug_int.(1); print_string ":";
	    print_int debug_int.(2); print_string ":";
	    print_int debug_int.(3); print_string ":";
	    print_int debug_int.(4); print_string ":";
	    print_int debug_int.(5);
	    (*      print_string !Sct_lambda.debug_message;*)
	    print_newline();
	  end;
	flush stdout;
    done;
;;

let start ()  =
  let id_debug = Thread.create debug_thread 0
  in print_string "";
;;
  

let exit_error message =
  print_string message;
  exit 2;
;;
