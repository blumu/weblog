(** Main module.
  The Size-change principle for the untyped lambda calculus and for a subset of core ML.

  History:

  1.8 
  - CoreML: star evaluation and call rules removed
  - Lambda calculus: approximation rule VarAG improved : jugdement forms are generated only for free occurences
  of the variable in the subexpression in which the variable has been defined! This solve the variable renaming problem.
  - Ml2lambda: consequence of the previous remark: all the code for variable renaming is now obsolete and have been
  put in commentary.

  1.7 8/08/2004
  - new: latex output for ML file
  - rules ApplyG corrected to handle if-then-else evaluation
  - FuncAppRec and FuncApp calls have merged
  - command line option -noh added (modifier for the -latex option)    
  - CoreML: approximation rule VarAG improved : jugdement forms are generated only for free occurences of the variable
  in the subexpression in which the variable has been defined! This solve the variable renaming problem!
  - CoreML: contains code to handle the star evaluation and call rules (this has to be removed since it is useless)

  1.6 3/08/2004
  - IMPLEMENTATION OF THE COREML SCP FINISHED !!!!
  - introduction of the special symbol ? in the syntax of the core ML language
  - modification of classes to make the code even more generic
  and to prepare for the CoreML SCT implementation.
  - the judgement forms are not stored in matrices instead of list
  this greatly speeds up the exhaustive application of rules as well,
  as well as the closure computation!
  - new: debugging features (command parameter -d) allows to print debuggin
  information during the computation. There is a separate thread
  for the debugging command prompt.

  1.5 23/07/2004
  - the equality relation for subexpressions has been simplified: two subexpression are considered to be equal if
    there are both the same variable or if they are the same subexpression node.
    (now two different subexpression which are equivalent are not considered to be equal unless they 
    correspond exactly to the same node)
    This makes the program run really faster!

  1.4 17/07/2004
  - code changed in order to prepare the code reuse for the core ml SCT:
    the module sct_untyped is defined on top of module sct through the use of classe inheritance

  1.3 17/06/2004
  - now the function print_lambda_expr only prints needed brackets
  - critical paths are printed if the given program is not SCT

  1.2 18/05/2004
  - parser: the \@ symbol used for application is now optional in the expression of the lambda expression
  - parser: the abreviation u v w for (u\@v) \@ w is accepted.

  1.1 17/05/2004
  - parser for simply typed lambda calculus with two examples: simple.lmd and churchnum.lmd
  - recording of the control points in the size-change graphs after each
  composition during the closure phase of the analysis
  - prints out the list of all descending loops when the program P is sc-terminating
  - now the rule VarAG is applied only if x is a subexpression of P
  - the closure phase now removes graphs repetition      

  1.0 14/05/2004
  - first working version


  @author William Blum
  @version 1.8

*)

open List;;
open Printf;;

(** print an error message and exit *)
let err_message file line col extra =
  Printf.printf "\"%s\" , line %d, col %d: %s\n" file line col extra;
  exit 1;;

(** SCT analysis of program prog with the set of size-change graphs scgs *)
let sct_analysis prog scgs =
  let sct,loops = prog#is_sct scgs in
    if sct then
      begin
	print_string "Program is size change terminating!\n";
	print_string "All the loops are descending:\n";
	prog#print_scgraphs loops
      end
    else
      begin
	print_string "Program is not size change terminating!\n";
	print_string "The critical (ie. not descending) loops are:\n";
	prog#print_scgraphs loops
      end;
    sct
;;

(** Main procedure. *)
let main () =
  let fns = ref [] in
  let latex = ref false
  and mlinput = ref false
  and mlconv = ref false
  and debug = ref false
  and latex_noh = ref false
  in
  let usage =  "Usage: sct [-v] [-d] [-latex [-noh]] [-l] [-ml [-conv]] file" in
    Arg.parse 
      [ "-v", Arg.Unit (function () -> Sct.verbose := true ), "verbose mode";
	"-d", Arg.Unit (function () -> debug := true ), "launch a debugging thread";
	"-l", Arg.Unit (function () -> mlinput := false; ), "input file is a lambda-calculus expression (default)";
	"-ml", Arg.Unit (function () -> mlinput := true ), "input file is  a CoreML expression";
	"-conv", Arg.Unit (function () -> mlconv := true ), "convert into lambda-expression (only with -ml option)";
	"-latex", Arg.Unit (function () -> latex := true ), "generate a latex xypic graph";
	"-noh", Arg.Unit (function () -> latex_noh := true ), "do not generate headers (only with -latex option)" 
      ]
      (function s -> fns := !fns @ [s]) usage;
    if length !fns <> 1 then begin fprintf stderr "%s\n" usage; exit 2 end;

    if !debug && not !latex then Debug.start();

    let in_file = hd !fns in
    let lexbuf = Lexing.from_channel (open_in in_file) in

    let parse_ml_expr() =
      try 
	Ml_parser.program Ml_lexer.token lexbuf
      with
	  Parsing.Parse_error ->
	    let tok = Lexing.lexeme lexbuf in
	      err_message in_file !Ml_lexer.lineno !Ml_lexer.colno
		(sprintf "syntax error at token '%s'" tok)	      
    in
	      
    let time_begin = Sys.time()
    and time_end = ref 0. in

      (* LAMBDA-CALCULUS OR CONVERTED CORE ML *)
      if (not !mlinput) || !mlconv then
	let expr =
	  if !mlconv then
	    Ml2lambda.ml2lambda (parse_ml_expr())
	  else
	    (try 
	       Parser.expression Lexer.token lexbuf
	     with
		 Parsing.Parse_error ->
		   let tok = Lexing.lexeme lexbuf in
		     err_message in_file !Lexer.lineno !Lexer.colno
		       (sprintf "syntax error at token '%s'" tok)	      
	    )
	in
	  
	let prog = Sct_lambda.program_of_lambdaexpr expr in
	  if !latex then
	    prog#to_latex !latex_noh
	  else
	    begin
	      print_string "Lambda expression to analyze: \n";
	      Sct_lambda.print_lambda expr; print_newline();
	      
	      if not (prog#is_closed()) then
		begin
		  print_string "The program expression is not closed!\n";	    
		  exit 0;
		end;	    
	      
	      print_string "Exhaustive application of the judgment form rules...\n";
	      flush stdout;
	      
	      let approx_scgs = prog#build_safe_scg() in
	      let sct = sct_analysis prog approx_scgs
	      in
		time_end := Sys.time();
	    end
      else
	begin
	  (* CORE ML *)
	  let expr = parse_ml_expr()
	  in	  
	  let prog = Sct_coreml.program_of_mlexpr expr
	  in
	    if !latex then
	      prog#to_latex !latex_noh
	    else
	      begin
		(* print_string "CoreML expression to analyze: \n";
		   Sct_coreml.print_expression  expr; print_newline(); *)
		if not (prog#is_closed()) then
		  begin
		    print_string "The program expression is not closed!\n";	    
		    exit 0;
		  end;	    
		
		print_string "Exhaustive application of the judgment form rules...\n";
		flush stdout;
	      	
		let scgs0,scgsHO = prog#build_safe_scg() in
		  print_string "=== SIZE-CHANGE PRINCIPLE FOR INTEGERS ===\n";
		  flush stdout;
		  let sct0 = sct_analysis prog scgs0
		  in
		    print_string "=== SIZE-CHANGE PRINCIPLE FOR HIGHER-ORDER EXPRESSION ===\n";
		    flush stdout;
		    let sctho = sct_analysis prog scgsHO; in		    
		      time_end := Sys.time();
		      if sct0 || sctho then
			print_string "Program is terminating on all input values!\n"
		      else
			print_string "Program is not size-change terminating.\n"
	      end;
	end;      
      if not !latex then
	begin
	  print_string "Execution time: ";
	  print_float (!time_end -. time_begin);
	  print_string "s\n";
	end;
      exit 0
;;

Printexc.catch main ();;
