(** CoreML to Lambda calculus conversion.

  This module provide functions to convert a program written in a subset of CoreML syntax into
  into a lambda calculus expression by preserving termination properties.

  History:
  1.0 14/06/2004
  - first version: handled structures
           let x = ...  in ...
           let rec f x = ... in ... (no mutual recursion)

  @author William Blum
*)


open Sct_lambda;;
open Sct_coreml;;

module IntMapInt =
  Map.Make(struct type t = int let compare = Pervasives.compare end)


(** build the expression for the church numeral n *)
let church_numeral n = 
  let rec aux = function
      0 -> Var("z")
    | i -> Appl(Var("s"), aux (i-1))
  in
    Abstr("s",Abstr("z", (aux n)))
;;


(** Build a sequence of Abstr construct.

  Example:
     [make_abstr ["x";"y";"z"] Appl(Var("x"),Var("y"))]
  returns
     [Abstr("x",(Abstr("y",Abstr("z",Appl(Var("x"),Var("y")))))]
*)
let make_abstr =
  List.fold_right (fun x e -> Abstr(x,e))
;;

(** Build a sequence of Fun construct.
  Example:
     [make_fun ["x";"y";"z"] MlAppl(MlVar("x"),MlVar("y"))]
  returns
     [Fun("x",(Fun("y",Fun("z",MlAppl(MlVar("x"),MlVar("y")))))]
*)
let make_fun =
  List.fold_right (fun x e -> Fun(x,e))
;;


(** [ml2lambda e] converts the ml expression e into a lambda-calculus expression. *)
let ml2lambda (e:ml_expr) :lambda_expr =
  let rec aux = function 
      MlVar(y) -> Var(y)
    | Fun(y,fune) -> Abstr(y, (aux fune))
    | MlAppl(e1,e2) -> Appl((aux e1), (aux e2))
	
    | Let(decl_list, in_expr) -> 
	let expand_decl lmbd_in_expr (f, params, body)  =
	  let lmbd_abstr_body = make_abstr params (aux body) in
	    Appl(Abstr(f, lmbd_in_expr), lmbd_abstr_body)
	in
	  List.fold_left expand_decl (aux in_expr) decl_list
	    
    | Letrec([decl], in_expr) -> 
	let ycombinator_ml = (Fun("p", MlAppl( Fun("q",MlAppl(MlVar("p"),Fun("s",
									     MlAppl(MlAppl(MlVar("q"),MlVar("q")),
										    MlVar("s"))
									    ))),
					       Fun("t",MlAppl(MlVar("p"),Fun("u",
									     MlAppl(MlAppl(MlVar("t"), MlVar("t")),
										    MlVar("u"))
									    ))))
				 ))
	in
	let expand_decl lmbd_in_expr (f, params, body)  =
	  let lmbd_abstr_body = make_abstr (f::params) (aux body) in
	    Appl(Abstr(f, lmbd_in_expr), (Appl((aux ycombinator_ml),lmbd_abstr_body)))
	in
	  expand_decl (aux in_expr) decl
	    
    | Letrec(decl_list, in_expr) ->
	failwith "mutual recursion not implemented!"
	  
    | If(cond,e1,e2) -> (
	match cond with 	  
	    EqTest(cleft,MlInt(0)) ->  
	      let ztest_ml = Fun("ztn", MlAppl(MlAppl(MlVar("ztn"), Fun("ztx",MlBool(false))),MlBool(true))) in
		aux (MlAppl(MlAppl(MlAppl(ztest_ml,cleft),e1),e2))		  
	  | MlBool(true) -> aux e1
	  | MlBool(false) -> aux e2
	  | _ -> failwith "Error: use of a test condition structure not implemented yet!" )

    | EqTest(l,r) -> failwith "Error: the equality test is only supported inside the condition of an 'if' structure!"
	
    | Pred ->
	let id_ml = Fun("ix", MlVar("ix")) in

	let pred_ml = Fun("pn", MlAppl(MlAppl(MlVar("pn"),
					      Fun("pz", MlAppl(MlAppl(MlVar("pz"),id_ml), 
							       MlAppl(Succ,MlVar("pz"))))),
				       Fun("a",Fun("b",MlInt(0)))))
	in aux pred_ml
	     
    | Succ ->
	let succ_ml = make_fun ["sk";"ss";"sz"] (MlAppl(MlVar("ss"),MlAppl(MlAppl(MlVar("sk"),MlVar("ss")),MlVar("sz"))))
 	in aux succ_ml

    | MlInt(i) ->
	church_numeral i
	    
    | MlBool(false) -> Abstr("fx",Abstr("fy",(Var("fy"))))
	  
    | MlBool(true) -> Abstr("tx",Abstr("ty",(Var("tx"))))

    | AnyInt ->
	print_string "Warning: The ml->lambda conversion program does not handle the special symbol ?. It has been replaced by the church numeral 0.\n";
	aux (MlInt(0))

  in
    aux e
;;

