(** If we allow recursive types in ocaml using the '-rectypes' argument then
  the evaluatation of the following expression (using the command 'ocaml -rectypes omega.ml')
  never terminates!
  **)
let omega = (function x -> x x) (function y -> y y) in true;;
