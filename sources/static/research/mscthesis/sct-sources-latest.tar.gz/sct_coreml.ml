
(** Implementation of the Size-change principle for a subset of CoreML.
  @author William Blum
*)

open Sct

(** Type for parsed coreml expressions *)
type ml_expr =
    MlVar of ident 
  | Fun of ident * ml_expr
  | MlAppl of ml_expr * ml_expr
  | Let of (ident * (ident list) * ml_expr) list  * ml_expr
  | Letrec of (ident * (ident list) * ml_expr) list  * ml_expr
  | If of ml_expr * ml_expr * ml_expr
  | MlInt of int 
  | AnyInt
  | MlBool of bool
  | EqTest of ml_expr * ml_expr
  | Pred
  | Succ
;;


(** Type used for subexpression nodes *)
type ml_node =
    VarN of int
  | FunN of int * sub_expr
  | FunrecN of int * int * sub_expr
  | ApplN of sub_expr * sub_expr
  | LetN of int * sub_expr * sub_expr
  | IfN of sub_expr * sub_expr * sub_expr
  | MlIntN of int 
  | AnyIntN
  | MlBoolN of bool
  | EqTestN of sub_expr * sub_expr
  | PredN of sub_expr
  | SuccN of sub_expr

(** A control points in coreml is either Anyint (?^int)
  or a subexpression.
**)

(** call judgment forms type  *)
type ml_calltype = Operator | Operand | FuncApp | IfThenElse | IfCond
		   | EqCond | PredSucc | LocalDef | FuncAppStar

type ml_evaltype = Normal

type ml_jftype = Call of ml_calltype | Evaluation of  ml_evaltype;;

(** type for the generated component in judgment forms *)
type ml_jfgen = scg_arc list * scg_arc list

(** type for a judgment form *)
type ml_jf = ml_jftype * ml_jfgen


class tml_program (v,e,fv) = 
object(self)
  inherit [ml_node, ml_jftype, ml_jfgen] tgrgen_program (v,e,fv) as super
     
    (** size of the subexpression array *)
    val ne = Array.length e

    (** active_expr.(i) = true only when the subexpression i has been activated
      (there is a call sequence from P to subexpression i)
    *)
    val activ_expr =
      let n = Array.length e in
	Array.make n false

    initializer 
      (* Activate the expression of P itself! *)
      activ_expr.(1) <- true;
	  
    (** convert a judgement form type into a string *)	     
    method string_of_jftype = function
	Call(c) ->
	  (match c with 
	       FuncApp -> "-c->"
	     | Operator -> "-r->"
	     | Operand -> "-d->" 
	     | IfThenElse -> "-if->" 
	     | IfCond -> "-ifcond->" 
	     | EqCond -> "-eq->"
	     | PredSucc -> "-predsucc->"
	     | LocalDef -> "-ldef->"
	     | FuncAppStar -> "-c*->" )
      | Evaluation(e) ->
	  (match e with 
	       Normal -> "||"
	  )

    (** convert a control point into a string *)	     
    method string_of_ctlpt pt = match pt with
	0 -> "?" (* Anyint *)
      | i ->
	  match expr.(i) with
	      VarN(x) -> variables.(x)^":"^(string_of_int i)
	    | _ -> string_of_int i

    (** [is_closed]
      @return true iff the lambda expression of the program is closed (contains no free variable)
    *)
    method is_closed () = 
      CtlPtSet.is_empty fv.(1)
		
    method eq_gen (g11,g12) (g21,g22) =
      (self#eq_arcs g11 g21) && (self#eq_arcs g12 g22)

    method print_gen (g1,g2) =
      self#print_scg_arcs g1;
      print_string "|";
      self#print_scg_arcs g2;


    method create_jf njf_type njf_p1 njf_p2 nfg_gen =
      super#create_jf njf_type njf_p1 njf_p2 nfg_gen;

      (* Apply the rules (PredAG) and (SuccAG) if possible *)
      match njf_type with
	  Evaluation(_) ->
	    if njf_p2 = 0 then
	      begin
		for oper_e = 1 to ne-1 do
		  match expr.(oper_e) with
		      PredN(e) when e = njf_p1 ->
			self#create_jf (Evaluation(Normal)) oper_e 0
			((self#gr_pred (fst nfg_gen)),[])
		    | SuccN(e) when e = njf_p1 ->
			self#create_jf (Evaluation(Normal)) oper_e 0
			  ((self#gr_succ (fst nfg_gen)),[])
		    | _ -> ()
		done;
	      end;
	| _ -> ()



    (** Constructs the approximation size change graphs by applying
      exhaustively the approximate judgment form rules.
      @return a matrix where each element .(i).(j) contain
      the list of judgment forms relating program point i to
      program point j.
    *)
    method find_approx_jforms () = 
      (* Apply the function f to all the subexpression indexes corresponding to
	 a free occurence of the variable x in subexpression e.
      *)
      let rec do_foreach_freeoccurence f x e =
	match expr.(e) with
	  | VarN(y) when x=y -> f e

	  | FunN(y,e0) when x <> y ->
	      do_foreach_freeoccurence f x e0

	  | FunrecN(fr,xr,e0) when fr <> x && xr <> x -> 
	      do_foreach_freeoccurence f x e0;

	  | LetN(xl,e0,e) ->
	      do_foreach_freeoccurence f x e0;
	      if xl <> x then do_foreach_freeoccurence f x e;

	  | VarN(_) | MlIntN(_) | MlBoolN(_) | AnyIntN
	  | FunN(_,_) | FunrecN(_,_,_) ->
	      ();

	  | IfN(econd,e1,e2) ->
	      do_foreach_freeoccurence f x econd;
	      do_foreach_freeoccurence f x e1;
	      do_foreach_freeoccurence f x e2;
	  | EqTestN(e1,e2) | ApplN(e1,e2) ->
	      do_foreach_freeoccurence f x e1;
	      do_foreach_freeoccurence f x e2
	  | PredN(e) | SuccN(e) ->
	      do_foreach_freeoccurence f x e;
      in

      (* [valueAG se] applies the rules (ValueAG)
	 to the subexpression se and its subexpressions.
	 (se is the expression on the left-most component in the new judgment form) *)
      let rec valueAG se =
	match expr.(se) with
	    FunN(_,e) | FunrecN(_,_,e) ->
	      let gr = self#gr_id_eq se in
		self#create_jf (Evaluation(Normal)) se se (gr,gr);
		valueAG e;

	  | MlIntN(_) | MlBoolN(_) | AnyIntN ->
	      let gr = self#gr_id_eq 0 in
		self#create_jf (Evaluation(Normal)) se 0 (gr,gr);

	  | LetN(_,e1,e2) | ApplN(e1,e2) | EqTestN(e1,e2) ->
	      valueAG e1; valueAG e2;
	      
	  | IfN(e,e1,e2) -> valueAG e; valueAG e1; valueAG e2;
	  | PredN(_) | SuccN(_) | VarN(_) -> ()


      (* [applyAG] applies the rule (ApplyAG) as many times as possible *)
      and applyAG()  = 
	for e1e2 = 0 to ne-1 do
	  match expr.(e1e2) with
	      IfN(e,e1,e2) ->
		for eprime = 0 to ne-1 do
		  let foreach_fst_premise = function
		      Call(IfThenElse), (gprime0,gprime) as jf ->
			(* find the second premise *)
			  for v = 0 to ne-1 do
			    let lst_snd_premises = 
			      Tools.map_filter
				(function _,g -> g)
				(function (Evaluation(_),_) -> true | _ -> false )
				jf_array.(eprime).(v)
			    in
			    let build_conclusion_jf (g0,g) =
			      self#create_jf (Evaluation(Normal)) e1e2 v ((self#scg_compose gprime0 g0), (self#scg_compose gprime g))
			    in
			      List.iter build_conclusion_jf lst_snd_premises
			  done;
		    | _ -> ()
		  in     
		    List.iter foreach_fst_premise jf_array.(e1e2).(eprime)
		done;

	    | ApplN(e1,e2) ->
		for eprime = 0 to ne-1 do
		  let foreach_fst_premise = function
		      Call(FuncApp), (gprime0,gprime)
		    | Call(IfThenElse), (gprime0,gprime) as jf
			->
			  (* find the second premise *)
			  for v = 0 to ne-1 do
			    let build_conclusion_jf (g0,g) =
			      self#create_jf (Evaluation(Normal)) e1e2 v ((self#scg_compose gprime0 g0), (self#scg_compose gprime g))
			    in
			    let lst_snd_premises = 
			      Tools.map_filter
				(function _,g -> g)
				(function (Evaluation(_),_) -> true | _ -> false )
				jf_array.(eprime).(v)
			    in
			      List.iter build_conclusion_jf lst_snd_premises
			  done;
		    |_ -> ()
		  in     
		    List.iter foreach_fst_premise jf_array.(e1e2).(eprime)
		done;
	    | _ -> ()
	done;

      (* [syntacticalCall se] applies the following rules:
	   (OperatorAG)	    (OperandAG)
  	   (IfCondCallAG)   (IfTrueCallAG)  (IfFalseCallAG)
	   (EqCondTrueAG)   (EqCondFalseAG)
	   (PredCallAG)     (SuccCallAG)
	   (LocalDefCallAG) (LocalBodyCallAG)
	 as many times as possible starting on subexpression e.
	 (se is the expression on the left-most component in the new judgment form)
      *)
      and syntacticalCallsAG (se:Sct.sub_expr) =
	let aux calltype e grfunc0 =
	  self#create_jf (Call(calltype)) se e (grfunc0 e,(self#gr_id_des e));
	  activ_expr.(e) <- true;
	  syntacticalCallsAG e
	in
	  match expr.(se) with
	      (* (OperatorAG)	    (OperandAG) *)
	    | ApplN(e1,e2) ->
		aux Operator e1 self#gr_idv;
		aux Operand e2 self#gr_idv;
		
	    (* (IfCondCallAG)   (IfTrueCallAG)  (IfFalseCallAG) *)
	    | IfN(etest,e1,e2) -> 
		aux IfCond etest self#gr_idv;
		aux IfThenElse e1 self#gr_id_eq;
		aux IfThenElse e2 self#gr_id_eq;

	    (* (EqCondTrueAG)   (EqCondFalseAG) *)
	    | EqTestN(e1,e2) ->
		aux EqCond e1 self#gr_idv;
		aux EqCond e2 self#gr_idv;
		
	    (* (PredCallAG) *)
	    | PredN(e) ->
		aux PredSucc e self#gr_idv;
	    (* (SuccCallAG) *)
	    | SuccN(e) ->
		aux PredSucc e self#gr_id_des;
		
	    (* (LocalDefCallAG) (LocalBodyCallAG) *)
	    | LetN(x,e1,e2) ->
		aux LocalDef e1 self#gr_idv;
		aux LocalDef e2 (self#gr_id_eq_subxx x);
		
	    | VarN(_) | FunN(_,_) | FunrecN(_,_,_) | MlIntN(_) | MlBoolN(_) | AnyIntN ->
		()
  
      (* [callAG] applies the rule (CallAG) *)
      and callAG() =
	  (* We apply the rule on expressions of type e1@e2 such that there is
	     a jf of the form:
             e -c-> e1@e2
	     Applying the (CallAG) rule will then produce a jf of the form:
	        e1@e2 -c-> e0
	  *)
	  
	  (* Look for jf of type "e -> e1@e2,G" *)
	  for e1e2 = 1 to ne-1 do
	    (* we are only interested in expression of type e1@e2 
	       which are activated (i.e. there is sequence of calls
	       from P to e1@e2 *)
	    match expr.(e1e2) with
		ApplN(e1,e2) when activ_expr.(e1e2) ->
		  (* for each evaluation of e2 *)
		  for v2 = 0 to ne-1 do
		    List.iter
		      (function
			   Evaluation(_),g2 ->
			     (* for each evaluation of e1 *)
			     for i = 0 to ne-1 do
			       Debug.set_int 1 e1e2;
			       Debug.set_int 2 v2;
			       Debug.set_int 3 i;	       
			       match expr.(i) with
				   FunN(x,e0)
				 | FunrecN(_,x,e0) ->
				     List.iter
				       (function
					    Evaluation(Normal),g1 ->
					      self#create_jf (Call(FuncApp)) e1e2 e0
					      ((self#gr_call0 x (fst g1) (fst g2)), (self#gr_call x (snd g1) (snd g2)));
					      activ_expr.(e0) <- true;
					      syntacticalCallsAG e0;
					  | _ -> ()
				       )
				       jf_array.(e1).(i);
				     
				 | _ -> ()
			     done
			 | _ -> ()
		      )		
      		      jf_array.(e2).(v2)
		  done;		  
	      | _ -> ()
	  done;
	
      (* [localAG] Applies the rule (LocalAG) *)
      and localAG() =
	(* Look for P sub-expressions of type let x = e1 in e2 *)
	  for lete = 1 to ne-1 do
	    match expr.(lete) with
		LetN(x,e1,e2) -> 
		  (* for each evaluation of e2 *)
		  for v2 = 0 to ne-1 do
		    List.iter
		      (function
			   Evaluation(_) as eval,g2 ->
			     (* for each evaluation of e1 *)
			     for v1 = 0 to ne-1 do
			       List.iter
				 (function
				      Evaluation(_),g1 ->
					self#create_jf eval lete v2
					((self#gr_local0 x (fst g1) e2 (fst g2)),
					 (self#gr_local x (fst g1) e2 (fst g2)))
				    | _ -> ()
				 )
				 jf_array.(e1).(v1)
			     done
			 | _ -> ()
		      )		
      		      jf_array.(e2).(v2)
		  done;		  
	      | _ -> ()
	  done


      (* [varAG] Applies the rule (VarAG) *)
      and varAG() = 
	(* Look for P sub-expressions of type e1@e2 *)
	for e1e2 = 1 to ne-1 do
	  match expr.(e1e2) with
	      ApplN(e1,e2) -> 
		(* for each evaluation of e2 *)
		for v2 = 0 to ne-1 do
		  List.iter
		    (function
			 Evaluation(_) as evaltype,g2 ->
			   (* for each evaluation of e1 *)
			   for i = 0 to ne-1 do
			     match expr.(i) with
				 FunN(x,e0) | FunrecN(_,x,e0) ->
				   List.iter
				   (function
					Evaluation(_), g1 ->
					  do_foreach_freeoccurence 
					  (function xi ->
					     self#create_jf evaltype xi v2
					     ((self#gr_var0 x),(self#gr_var x v2))
					  )
					  x e0
				      | _ -> ()
				   )
				   jf_array.(e1).(i)
			       | _ -> ()
			   done
		       | _ -> ()
		    )		
      		    jf_array.(e2).(v2)
		done;		
	    | _ -> ()
	done

      (* [varRecAG] Applies the rule (VarRecAG) *)
      and varRecAG() =
	 for v = 1 to ne-1 do
	    match expr.(v) with
		FunrecN(f,x,e0) ->
		  do_foreach_freeoccurence 
		  (function fi ->
		     self#create_jf (Evaluation(Normal)) fi v
		     ((self#gr_var0 f),(self#gr_var f v))
		  )
		  f e0
	      | _ -> ()
	  done;

      (* [varLetAG] Applies the rule (VarLetAG) *)
      and varLetAG() = 
	(* Look for P sub-expressions of type let x = e1 in e2 *)
	for lete = 1 to ne-1 do
	  match expr.(lete) with
	      LetN(x,e1,e2) ->
		
		(* for each evaluation of e1 *)
		for v1 = 0 to ne-1 do
		  List.iter
		    (function
			 (Evaluation(_) as eval),g1 ->
			   do_foreach_freeoccurence 
			   (function xi ->
			      self#create_jf eval xi v1
			      ((self#gr_var0 x),(self#gr_var x v1))
			   )
			   x e2
		       | _ -> ()
		    )
		    jf_array.(e1).(v1)
		done		
	    | _ -> ()
	done
      in

      (* Apply all the rules until no new judgment form is found *)
      let last_nb_jf = ref 0 in
	(* create the jf ?||? (axiom ValueAG) *)
	self#create_jf (Evaluation(Normal)) 0 0 ((self#gr_id_eq 0),(self#gr_id_eq 0));

	varRecAG();
	valueAG 1;
	syntacticalCallsAG 1;
	(* do the exhaustive application of rules *)
	while !nb_jf > !last_nb_jf do
	  if !Sct.verbose then
	    begin
	      print_string "***** ";
	      print_int !nb_jf;
	      print_string " jfs\n\n";
	    end;
	  last_nb_jf := !nb_jf;
	  callAG();
	  applyAG();
	  varAG();
	  varLetAG();
	  localAG();
	done;
	print_string "\nNumber of jf:";
	print_int !nb_jf;
	print_string "\n";


    
    (** Build the sets absint_0(P) and absint_+(P).
      One for the ground type SCP and one for the high-order SCP.
      These sets of size_change graphs are safe for P.
      @return a pair of two matrices (one for each SCP)
      containing the graphs *)
    method build_safe_scg() :scgs_mat*scgs_mat =
      self#find_approx_jforms() ;
      
      print_string "Preparing for the closure computation...\n";
      flush stdout;
      let n = Array.length expr in
      let mat_scgs_0 = Array.make_matrix n n [] in
      let mat_scgs_HO = Array.make_matrix n n [] in
	for i = 0 to n-1 do
	  for j = 0 to n-1 do
	    let call_jfs = List.filter 
			     (function Call(_),_ -> true | _ -> false) 
			     jf_array.(i).(j)
	    in
	      mat_scgs_0.(i).(j) <- List.map
		(function (_,(arcs,_)) -> arcs,[])
		call_jfs;
	      mat_scgs_HO.(i).(j) <- List.map
		(function (_,(_,arcs)) -> arcs,[] )
		call_jfs

	  done;
	done;
	mat_scgs_0,mat_scgs_HO
	  

    (** convert a lambda program into a xypic latex figure
      representing the tree of the expression
      @param noheaders if true then the document headers are not generated  *)
    method to_latex noheaders  =
      let rec print_indent indent =
	for i = 1 to indent do
	  print_string "  ";
	done;
      in
      let rec print_subexp indent e =
	print_string "\\fbox{";
	print_int e; print_string ":}";
	(match expr.(e) with
	     VarN(v) ->
	       print_string (variables.(v));
	   | FunN(x,se) ->
	       print_string ("fun "^variables.(x)^" -> ");
	       print_subexp indent se;
	   | FunrecN(f,x,se) ->
	       print_string ("fun "^variables.(f)^"=("^variables.(x)^")-> ");
	       print_subexp indent se;
	       
	   | ApplN(e1,e2) ->
	       print_string "(";
	       print_subexp indent e1;
	       print_string " ";
	       print_subexp indent e2;
	       print_string ")";
	       
	   | LetN(x,e,e2) ->
	       print_string ("let "^variables.(x)^" = ");
	       print_newline();
	       print_indent (indent+1);
	       print_subexp (indent+1) e;
	       print_string "\n";
	       print_indent indent;
	       print_string "in\n";
	       print_indent (indent+1);
	       print_subexp (indent+1) e2;
	       
	   | IfN(e,e1,e2) ->
	       print_string "\n";
	       print_indent indent;
	       print_string "if ";
	       print_subexp indent e;
	       print_string " then\n";
	       print_indent (indent+1);
	       print_subexp (indent+1) e1;
	       print_string "\n";
	       print_indent indent;
	       print_string "else\n";
	       print_indent (indent+1);
	       print_subexp (indent+1) e2;
	       
	   | MlIntN(i) ->
	       print_int i;
	   | AnyIntN ->
	       print_string "?"
	   | MlBoolN(true) ->
	       print_string "true"
	   | MlBoolN(false) ->
	       print_string "false"
	   | EqTestN(e1,e2) ->
	       print_string "(";
	       print_subexp indent e1;
	       print_string "=";
	       print_subexp indent e2;
	       print_string ")";
	       
	   | PredN(se) ->
	       print_string "(pred ";
	       print_subexp indent se;
	       print_string ")";
	       
	   | SuccN(se) ->
	       print_string "(succ ";
	       print_subexp indent se;
	       print_string ")";
	);

      in
	if not noheaders then
	  begin
	    print_string "\n\\documentclass{article}\n";
	    print_string "\\usepackage{listings}\n";
	    print_string "\\usepackage{fancyvrb}\n";
	    print_string "\\begin{document}\n";
	  end;

	print_string "\\fvset{commandchars=\\\\\\{\\}}\n";
	print_string "\\lstset{fancyvrb=true}\n";
	print_string "\\lstset{breaklines=true}\n";

	print_string "\\begin{Verbatim}[fontsize=\\footnotesize, frame=lines]\n";
	print_subexp 0 1;
	print_string ";;\n";
	print_string "\\end{Verbatim}\n";
	
	if not  noheaders then print_string "\\end{document}\n";
      
end



(** [variables_in e] returns the set containing all the variables appearing in the lambda expression e
*)
let variables_in e =
  let module StringSet = Set.Make(struct type t = string let compare = Pervasives.compare end)
  in    
  let rec aux = function
      MlVar(x) -> StringSet.singleton x
    | Fun(x,e) -> StringSet.add x (aux e)
    | MlAppl(Succ,e2) | MlAppl(Pred,e2) -> aux e2

    | EqTest(e1,e2) | MlAppl(e1,e2) -> StringSet.union (aux e1) (aux e2)

    | Let(defs,e)
    | Letrec(defs,e) ->	
	let add_one_def s (x,param,e0) =
	  StringSet.union 
	    s
	    (StringSet.union (aux e0)
	       (StringSet.add x (List.fold_right (StringSet.add) param StringSet.empty))
	    )
	in
	  List.fold_left add_one_def (aux e) defs   

    | If(e,e1,e2) ->
	StringSet.union (aux e) (StringSet.union (aux e1) (aux e2))
    | MlInt(_) | MlBool(_) | AnyInt -> StringSet.empty
    | Pred  | Succ -> failwith "(variables_in) bad use of Pred Succ operators!"
  in
    StringSet.elements (aux e)
;;

(**  [nb_nodes e] returns the number of nodes in the tree representing the lambda expression e *)
let rec nb_nodes e = match e with
    MlVar(_) | MlInt(_) | MlBool(_) | AnyInt -> 1
  | Fun(_,q) -> 1 + (nb_nodes q)
  | MlAppl(Succ,e2) | MlAppl(Pred,e2) -> 
      1 + (nb_nodes e2)
  | MlAppl(e1,e2) | EqTest(e1,e2) -> 1 + (nb_nodes e1) + (nb_nodes e2)

  | Let([_,param,e0],e) ->
      1 + (List.length param) + (nb_nodes e0) + (nb_nodes e)

  | Letrec([_,[],e0],e) ->
      failwith "(nb_nodes) recursive defined functions need at least one parameter!"

  | Letrec([_,param,e0],e) ->
      1 + (List.length param) + (nb_nodes e0) + (nb_nodes e)

  | If(e,e1,e2) ->
      1 + (nb_nodes e) + (nb_nodes e1) + (nb_nodes e2)

  | Pred | Succ -> failwith "(nb_nodes) bad use of Pred Succ operators!"
  | _ -> failwith "(nb_nodes) use of a syntax structure not implemented yet!"

;;

(** [program_of_mlexpr e] builds the program data structure from the lambda expression [e]. *)
let program_of_mlexpr e =
  (* array containing the variables identifier *)
  let var_array = Array.of_list (variables_in e) in

  (* number of variables *)
  let nvar = Array.length var_array in
    
  (* number of nodes in the tree representing the expression *) 
  let nnodes = nb_nodes e in
    
  (* allocate an array for storing all the nodes of the lambda expression *)
  let subexpr_array = Array.make (1+nnodes) (VarN(-1)) in

  (* allocate an array for storing the set of free variables *)
  let fv_array = Array.make (1+nnodes) (CtlPtSet.empty) in
    

  (* get the variable number from its identifier. *)
  let vardecl_number x =
    let v = ref 0 and found = ref false in
      while (not !found) && !v <nvar do
	if var_array.(!v) = x then
	  found := true
	else
	  incr(v);
      done;
      if not !found then
	failwith "bug in program_of_mlexpr (variable not found)!"
      else
	!v
  in
    
  let rec create_fun i = function
      [] -> i
    | t::q -> subexpr_array.(i) <- FunN(t,i+1); create_fun (i+1) q
  and compute_fun_fv i = function
      [] -> ()
    | t::q ->
	compute_fun_fv (i+1) q;
	fv_array.(i) <- CtlPtSet.diff fv_array.(i+1) (CtlPtSet.singleton t);
  and assign n e =
    match e with
      MlVar(x) -> 
	let varnum = vardecl_number x in
	  fv_array.(n) <- CtlPtSet.singleton varnum;
	  subexpr_array.(n) <- VarN(varnum);
	  n+1
    | Fun(x,f) ->
	let varnum = vardecl_number x in
	let p = assign (n+1) f in
	  fv_array.(n) <- CtlPtSet.diff fv_array.(n+1) (CtlPtSet.singleton varnum);
	  subexpr_array.(n) <- FunN(varnum,n+1); p

    | MlAppl(Succ,e2)-> 
	let p = assign (n+1) e2 in
	  fv_array.(n) <- fv_array.(n+1);
	  subexpr_array.(n) <- SuccN(n+1); p

    | MlAppl(Pred,e2) -> 
	let p = assign (n+1) e2 in
	  fv_array.(n) <- fv_array.(n+1);
	  subexpr_array.(n) <- PredN(n+1); p

    | MlAppl(e1,e2) ->
	let p = assign (n+1) e1 in
	let q = assign p e2 in
	  fv_array.(n) <- CtlPtSet.union fv_array.(n+1) fv_array.(p);
	  subexpr_array.(n) <- ApplN(n+1,p); q

    | EqTest(e1,e2) ->
	let p = assign (n+1) e1 in
	let q = assign p e2 in
	  fv_array.(n) <- CtlPtSet.union fv_array.(n+1) fv_array.(p);
	  subexpr_array.(n) <- EqTestN(n+1,p); q

    | Let([x,param,e0],e) ->
	let xi = vardecl_number x
	and parami = List.map vardecl_number param in
	  	  
	let p = create_fun (n+1) parami in
	let q = assign p e0 in
	let r = assign q e in
	  
	  subexpr_array.(n) <- LetN(xi,n+1,q);
	  
	  compute_fun_fv (n+1) parami;
	  fv_array.(n) <- CtlPtSet.union fv_array.(n+1) (CtlPtSet.diff fv_array.(q) (CtlPtSet.singleton xi) );
	  r


    | Letrec([f,[],ef],e) ->
	failwith "(nb_nodes) recursive defined functions need at least one parameter!"

    | Letrec([f,x::param,ef],e) ->
	let xi = vardecl_number x
	and fi = vardecl_number f
	and parami = List.map vardecl_number param in

	let p = create_fun (n+2) parami in
	let q = assign p ef in
	let r = assign q e in

	  subexpr_array.(n+1) <- FunrecN(fi,xi,n+2);
	  subexpr_array.(n) <- LetN(fi,n+1,q);

	  compute_fun_fv (n+2) parami;
	  fv_array.(n+1) <- CtlPtSet.diff (CtlPtSet.diff fv_array.(n+2) (CtlPtSet.singleton xi)) (CtlPtSet.singleton fi); 
	  fv_array.(n) <- CtlPtSet.union fv_array.(n+1)  (CtlPtSet.diff fv_array.(q) (CtlPtSet.singleton fi) );
	  r

    | If(e,e1,e2) ->
	let p = assign (n+1) e in
	let q = assign p e1 in
	let r = assign q e2 in
	  fv_array.(n) <- CtlPtSet.union (CtlPtSet.union fv_array.(n+1) fv_array.(p)) fv_array.(q);
	  subexpr_array.(n) <- IfN(n+1,p,q); r

    | MlInt(i) ->
	fv_array.(n) <- CtlPtSet.empty;
	subexpr_array.(n) <- MlIntN(i);
	n+1
    | AnyInt ->
	fv_array.(n) <- CtlPtSet.empty;
	subexpr_array.(n) <- AnyIntN;
	n+1
    | MlBool(b) -> 
	fv_array.(n) <- CtlPtSet.empty;
	subexpr_array.(n) <- MlBoolN(b);
	n+1	

    | Pred | Succ -> failwith "(assign) bad use of Pred Succ operators!"
    | _ -> failwith "(assign) use of a syntax structure not implemented yet!"
  in
    (* start the numbering of the nodes from 1 (0 is reserved for ?^int ) *)
    let _ = assign 1 e in
      (* create the program object *)
      new tml_program( var_array, subexpr_array, fv_array )
;;
