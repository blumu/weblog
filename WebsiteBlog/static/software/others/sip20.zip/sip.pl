#!e:/bin/prog/perl/5.005/bin;

# Auteur :            William BLUM
# Cr�� le :           1 dec 1998
# Modifi� le :        6 apr 1999
# Copyright :         (c) William BLUM 1998-1999
# Version :           2.0

# Vous avez la libert� d'utiliser, de modifier et de distribuer librement ce programme.
#
#   * Si vous le distribuez, n'oubliez pas de fournir tous les autres fichiers
#   qui ont �t� fournis avec le logiciel.
#   * Si vous l'utilisez pour r�aliser des installations, vous �tes tenu de citer mon nom
#   dans une bo�te de dialogue de votre logiciel pour avoir particip� � la cr�ation du
#   programme d'installation.
#   * Ne vous appropriez pas ce logiciel : il appartient � tous le monde.
#   * Ne le vendez pas.
#   * Faites en bon usage.
#   * Vous avez le droit de corriger les bugs que vous d�couvrerez
#

################
# Variables globales :
#
# * Pour chaque cl�e d�finie dans le script sip, un �l�ment $cle est ajout� dans le tableau
#               associatif %DEF. Cet �l�ment a pour valeur $val :
#
#               $DEF{$cle} = $val;
#
#
# * Liste des cl�es � d�finir obligatoirement dans le script sip
#
@cles_obligatoires = ( "IEXPRESS", "PKZIP", "FILES", "OUTPUT", "TITLE", "BASENAME", "SETUP_INF", "FILE_ID", "INST_DIR_PROMPT", "REGISTRY", "SHORTCUTS", "INST_BEGIN_PROMPT", "INST_END_PROMPT");
#
#
# * Liste des cl�es r�serv�es (d�finies par le programme SIP lui m�me)
#
@cles_reserves = ( "INF_DESTINATIONDIRS", "INF_LISTFILES", "INF_KEY_COPYFILES", "INF_ADD_SHORTCUT", "INF_ADD_SHORTCUT_NT", "INF_DEL_SHORTCUT", "INF_DEL_SHORTCUT_NT", "INF_DEL_DIRS", "SHORT_DATE", "LONG_DATE", "CHICAGO" );
#
# * En mode DEBUG, des informations suppl�mentaires sont affich�s � l'�cran
#
$DEBUG = 0;
#
#
#######

use File::Copy;


###########
# Test si une cl�e fait partie des cl�es r�serv�es
#
sub TestCleReservee
{
  my $cle = pop;
  my $ok = 1;

  foreach( grep { $_ eq $cle } @cles_reserves )
  {
    print "(ERREUR) La red�finition de la cl�e \"$_\" est interdite !\n";
    $ok = 0;
  }

$ok;
}

###########
# Test si toute les cl�es obligatoires ont �t� d�finie
#
sub VerifCleObligatoire
{
  my $ok = 1;

  foreach( grep { $DEF{$_} eq "" } @cles_obligatoires )
  {
    print "(ERREUR) La cl�e \"$_\" n'a pas �t� d�finie !\n";
    $ok = 0;
  }
$ok;
}

###########
# Lit le script de packaging (.sip) fin d'extraire la valeur de toutes les cl�es
#
sub lit_build_script
{
  my $filename = pop();
  my $cle;
  my $val;
  my @buff;
  my $ok = 1;

  print "    - [lit_build_script]\n      Lecture du script de packaging ($filename)\n";

  open(SIP, $filename) or die "\n(ERREUR) Impossible d'ouvrir le fichier $filename ($!)\n";
  @buff = <SIP>;

  $continue_section = '';
  foreach $ligne (@buff)
  {               
    # supprime les remarques (pr�c�d�s par le symbole #)
    $ligne =~ s/([^#]*).*/$1/;

    # fin d'une cl�e pr�c�dente �tal�e sur plusieurs lignes ?
    if( $ligne =~ />>/ )
    {
      $continue_section = '';
    }
    # suite d'une pr�c�dente cl�e �tal�e sur plusieurs lignes ?
    elsif( not $continue_section eq '' )
    {
      TestCleReservee($1) or $ok =0;
      $DEF{$continue_section} .= $ligne ;
      if( $DEBUG ) { print "[lit_build_script..] $ligne"; }
    }
    # nouvelle cl�e sur une ligne ?
    elsif( $ligne =~ /([^ ]*) *= *\"(.*)\"/ )
    {
      TestCleReservee($1) or $ok =0;
      $DEF{$1} = $2;
      if( $DEBUG ) { print "[lit_build_script] $1 = $DEF{$1}\n"; }
    }
    # nouvelle cl�e �tal�e sur plusieurs lignes ?
    elsif( $ligne =~ /([^ ]*) *= *<</ )
    {
      $continue_section = $1;
      if( $DEBUG ) { print "[lit_build_script.] $1 =\n"; }
    }
  }

  # 2 V�rifie que toute les cl�s indispensables ont �t� d�finies
  VerifCleObligatoire() or $ok =0;

  # 3 Pour chaque cl�e, remplace toute r�f�rence � une autre cl� par sa valeur
  foreach ( keys (%DEF) )
  {
    $DEF{$_} = Replace_cles($DEF{$_});
  }

  close SIP;

$ok;
}


###########
# Cr�e (r�cursivement) une liste des tous les sous-r�pertoires d'un r�pertoire donn�.
#
sub GetSubDirsList
{
  my $rep  = @_[0];
  local (*lst_rep )= @_[1];

  push(@lst_rep, $rep);

  opendir(DIR, $rep) or die "\n[GetSubDirsList] (ERREUR) Impossible d'ouvrir le r�pertoire '$rep' ($!)\n";

  # Pour tous les sous-r�pertoires ne se finissant pas par un point
  foreach( grep { (-d "$rep\\$_") && ( $_ !~ /\.$/) } readdir(DIR) )
  {
    GetSubDirsList("$rep\\$_", \@lst_rep)
  }

  closedir(DIR);
}

###########
# Ajoute un fichier � la liste des fichiers � installaler et copie le dans le r�pertoire temporaire
#
sub AjoutEtCopieFichier
{
  local (*LISTE) = @_[0];
  my $src_path = @_[1];
  my $install_rep = @_[2];
  my $install_sousrep = @_[3];
  my $num_fich = @_[4];

  # extrait le nom du fichier � partir du chemin complet
  $src_path =~ /([^\/:\\]*)$/;     
  $nomfich = $1;

  # supprime les anti-slashs au d�but et � la fin
  $install_sousrep =~ s/^\\?(.*)\\?$/$1/;


  if( $DEBUG ) { print "[AjoutEtCopieFichier] {\"$install_rep,$install_sousrep\"}+=\"$nomfich,file.$num_fich\"\n"; }

  # copie du fichier
  if ( $src_path =~ /$DEF{BASENAME}\.INF/ )
  {  # le fichier script inf est par d�faut d�j� copi� 
    $LISTE{$install_rep.','.$install_sousrep} .= "$DEF{BASENAME}\.INF,,,33\n";
  }
  else  
  {
    $LISTE{$install_rep.','.$install_sousrep} .= "$nomfich, file\.$num_fich,,33\n";
    copy($src_path, "sip.tmp\\file\.$num_fich") or die "\n(ERREUR) Impossible de copier le fichier '$src_path' ($!)\n";
  }
}

###########
# G�n�re la liste des fichiers � installer et copie ces fichiers dans un r�pertoire temporaire
#
# But : 1 Copie les fichiers � installer dans un repertoire temporaire
#
#       2 Cr�e � partir de l'analyse de la cl�e FILES les cl�es INF_KEY_COPYFILES, INF_LISTFILES et INF_DESTINATIONDIRS
#         utilis�es par le script INF
#
# Remarque sur la copie de l'arborescence :
#
#       On copie tous les fichiers dans le r�pertoire temporaire avec des noms de la forme 'FILE.xxx'
#       o� xxx est le num�ro du fichier car le programme d'installation cr�� par IExpress ne prend pas 
#       en compte l'arborescence des r�pertoires. Ce qui fait que ca merde lorsque deux fichiers situ�s
#       dans des r�pertoires diff�rents portent le m�me nom.
#
sub gen_liste_fichiers
{
  my $option;  
  my $src_path;
  my $install_path;
  my $install_dir;
  my $install_subdir;
  my @src_subdirs;

  my $fichier;
  my $nb_fichiers;
  my %LISTE_FICHIERS;

  # 1 Copie les fichiers � installer dans un repertoire temporaire
  print "\n    - [gen_liste_fichiers]\n      Copie les fichiers � installer dans un r�pertoire temporaire\n";

  $nb_fichiers = 0;  
  %LISTE_FICHIERS = ();
  foreach ( split("\n" , $DEF{FILES}) )
  {
    @param = split(/,[ \t]*/, $_);

    $option = @param[0];
    $src_path = @param[1];
    $install_path = @param[2];
    $install_dir = @param[3];

    if( $option =~ /NORMAL/ )               # fichier ou groupe de fichiers
    {
      @matchedfiles = glob($src_path);

      if( scalar(@matchedfiles) == 0 )
      {       
        die "\n[gen_liste_fichiers] (ERREUR) Fichier introuvable '$src_path'\n";
      }

      foreach( @matchedfiles )
      {
        AjoutEtCopieFichier(\%LISTE_FICHIERS, $_, $install_path, $install_dir, $nb_fichiers);
        $nb_fichiers++;
      }

    }
    elsif( $option =~ /SUBDIR/ )            # avec les sous-repertoires
    {  
      # Ajoute les fichiers de tous les sous-r�pertoires
      GetSubDirsList($src_path, \@src_subdirs);
      foreach $src_subdir ( @src_subdirs )
      {
        # cr�e le chemin d'installation en enlevant la racine du chemin d'acc�s pour en faire un chemin relatif

        $src_path =~ s|\\|/|g;          # remplace les antislashs par des slashs afin
        $src_subdir =~ s|\\|/|g;        # qu'ils ne soient pas interpr�t�s comme expressions r�guli�res

        $src_subdir =~ /$src_path(.*)/o;

        $install_subdir = $1;
        $install_subdir =~ s|/|\\|g;
        $install_subdir = $install_dir.$install_subdir;

        $src_subdir =~ s|/|\\|g;

        foreach( grep { -f "$_" } glob("$src_subdir\\*.*") )
        {
          AjoutEtCopieFichier(\%LISTE_FICHIERS, $_, $install_path, $install_subdir, $nb_fichiers);
          $nb_fichiers++;
        }
      }
    }
  }

  # 2 Cr�e les cl�es INF_KEY_COPYFILES, INF_DESTINATIONDIRS et INF_LISTFILES utilis�es par le script INF
  print "\n    - [gen_liste_fichiers]\n      G�n�re la liste des fichiers � installer\n";

  $DEF{INF_KEY_COPYFILES} = '';
  $DEF{INF_LISTFILES} = '';
  $DEF{INF_DESTINATIONDIRS} = '';
  $DEF{INF_DEL_DIRS} = '';
  foreach $dest ( keys(%LISTE_FICHIERS) )
  {

    # Cr�e le nom de la section en rempla�ant les anti-slash et les virgules du chemin correspondant par des underscore '_'
    $section = $dest;
    $section =~ s/[\\\. ,]/_/g;
    # extrait le nom du repertoire et du sous r�pertoire
    $dest =~ /([^,]*),(.*)/; $rep = $1; $sousrep = $2;

    unless( $sousrep eq '' )  { $DEF{INF_DEL_DIRS} .= "%$rep%\\$sousrep\n"; }
    $DEF{INF_KEY_COPYFILES} .= $section.', ';
    $DEF{INF_DESTINATIONDIRS} .= "$section=$dest\n";
    $DEF{INF_LISTFILES} .= "[$section]\n$LISTE_FICHIERS{$dest}\n";
  }
}


# g�n�re la liste des raccourcis
sub gen_liste_raccourcis
{
  print "\n    - [gen_liste_raccourcis]\n      G�n�re la liste des groupes et raccourcis � cr�er\n";

  $DEF{INF_ADD_SHORTCUT} = '';
  $DEF{INF_ADD_SHORTCUT_NT} = '';
  $DEF{INF_DEL_SHORTCUT} .= '';
  $DEF{INF_DEL_SHORTCUT_NT} .= '';
  foreach ( split("\n" , $DEF{SHORTCUTS}) )
  {
    @param = split(/,[ \t]*/, $_);  # extrait les param�tres s�par�s par des virgules

    $cmd = @param[0];
    $nom = @param[1];

    $nom =~ s/\"([^\"]*)\"/$1/;     # garde que ce qui est entre guillemets

    if( $cmd =~ /GROUP/ )     # Nouveau groupe
    {
      $DEF{INF_ADD_SHORTCUT} .= qq{setup.ini, progman.groups,, "group1=$nom"\n};
      $DEF{INF_ADD_SHORTCUT_NT} .= qq{setup.ini, progman.groups,, "group1=$nom"\n};
      $DEF{INF_DEL_SHORTCUT} .= qq{setup.ini, progman.groups,, "group1=$nom"\n};
      $DEF{INF_DEL_SHORTCUT_NT} .= qq{setup.ini, progman.groups,, "group1=$nom"\n};
    }
    elsif( $cmd =~ /ITEM/ )   # Nouveau raccourci
    {
      $fic = @param[2];
      $para = @param[3];
      $fic_ico = @param[4];
      $num_ico = @param[5];
      $start_rep = @param[6];

      $DEF{INF_ADD_SHORTCUT} .= qq{setup.ini, group1,, """$nom"", ""$fic"" $para,""$fic_ico"", $num_ico,, ""$startrep"""\n};
      $DEF{INF_ADD_SHORTCUT_NT} .= qq{setup.ini, group1,, """$nom"", """"""$fic"""""" $para, ""$fic_ico"", $num_ico,, """"$startrep"""""\n};
      $DEF{INF_DEL_SHORTCUT} .= qq{setup.ini, group1,, """$nom"""\n};
      $DEF{INF_DEL_SHORTCUT_NT} .= qq{setup.ini, group1,, """$nom"""\n};

    }
  }
}


###########
# Remplace les noms de cl�s contenus dans une chaine de caract�res par leur valeurs
#
sub Replace_cles
{
  my $buf = pop;
  my $cle;
  
  foreach $cle ( keys (%DEF) )
  {
    $buf =~ s/\$$cle\$/$DEF{$cle}/g;
  }
$buf;
}


###########
# G�n�ration du script d'installation (inf)
#     
sub gen_setup_inf
{
  print "\n    - [gen_setup_inf]\n      G�n�ration du script INF $DEF{BASENAME}.INF\n";

  open(DST, ">sip.tmp\\$DEF{BASENAME}.INF") or die "\n(ERREUR) Impossible de cr�er le fichier sip.tmp\\$DEF{BASENAME}.INF ($!)\n";
 
  # remplace dans la cl�e INF les r�f�rences � des cl�es par leur valeur et copie le r�sultat dans le fichier INF
  print DST Replace_cles($DEF{SETUP_INF}) ;

  close DST;
}

###########


############
# G�n�ration du script (setup.sed) utilis� par IExpress pour cr�er le programme d'installation
#
sub gen_iexpress_sed
{
  print "\n    - [gen_iexpress_sed]\n      G�n�ration du script pour IExpress (setup.sed)\n";
  open(DST, '>sip.tmp\\setup.sed');

    print DST "[Version]\n";
    print DST "Class=IEXPRESS\n";
    print DST "SEDVersion=3\n";
    print DST "[Options]\n";
    print DST "PackagePurpose=InstallApp\n";
    print DST "ShowInstallProgramWindow=0\n";
    print DST "HideExtractAnimation=0\n";
    print DST "UseLongFileName=0\n";
    print DST "InsideCompressed=0\n";
    print DST "CAB_FixedSize=0\n";
    print DST "CAB_ResvCodeSigning=0\n";
    print DST "RebootMode=I\n";     
    print DST "TargetName=$DEF{OUTPUT}\\$DEF{BASENAME}.EXE\n";  # fichier installation g�n�rer par IExpress
    print DST "FriendlyName=$DEF{TITLE}\n";                     # titre de l'application
    print DST "AppLaunched=$DEF{BASENAME}.INF\n";               # nom du fichier INF � ex�cuter par le bootstrap
    print DST "SourceFiles=SourceFiles\n";                      # nom de la section contenant la liste des fichiers

    print DST "InstallPrompt=$DEF{INST_BEGIN_PROMPT}\n";    # message avant l'installation
    print DST "DisplayLicense=\n";
    print DST "FinishMessage=$DEF{INST_END_PROMPT}\n";      # message apr�s l'installation

    print DST "PostInstallCmd=<None>\n";

    print DST "AdminQuietInstCmd=\n";
    print DST "UserQuietInstCmd=\n";



    print DST "[SourceFiles]\n";
    print DST "SourceFiles0=sip.tmp\n";

    print DST "[SourceFiles0]\n";
  

    opendir(DIR, "sip.tmp") or die "\n(ERREUR) Impossible d'ouvrir le r�pertoire 'sip.tmp' ($!)\n";
      

      foreach ( grep { ($_ =~ /FILE\./i) or ($_ =~ /$DEF{BASENAME}.INF/i) } readdir(DIR) )
      {
        if( $DEBUG ) {  print "          . $_\n"; }
        print DST $_."=\n";       # �cris le nom du fichier
      }

    closedir(DIR);

  close(DST);
}

############
# G�n�ration du programme d'installation (EXE)
#       
sub gen_setup_exe
{
  print "\n    - [iexpress]\n      G�n�ration du programme d'installation ($DEF{BASENAME}.EXE)\n";
  system("$DEF{IEXPRESS} /N /M sip.tmp\\setup.sed") == 0
      or die "\n(ERREUR) La commande suivante a �chou�e :\n",
            "  $DEF{IEXPRESS} /N /M sip.tmp\\setup.sed \n";
}


###########
# g�n�ration du fichier d'information (FILE_ID.DIZ)
#
sub gen_file_id
{
  print "\n    - [gen_file_id]\n      G�n�ration du fichier d'information (file_id.diz)\n";

  open(DIZ, ">$DEF{OUTPUT}\\file_id.diz");

    # ajoute le texte contenu dans le fichier de packaging (.sip)
    print DIZ $DEF{FILE_ID};

  close DIZ;
}


###########
# Compression des fichier finaux (.EXE et FILE_ID.DIZ)
#       
sub compression_finale
{
  print "\n    - [pkzip]\n      Compression $DEF{BASENAME}.EXE+file_id.diz ($DEF{BASENAME}.ZIP)\n";
  system("$DEF{PKZIP} $DEF{OUTPUT}\\$DEF{BASENAME}.ZIP $DEF{OUTPUT}\\$DEF{BASENAME}.EXE $DEF{OUTPUT}\\file_id.diz >nul\n") == 0
      or die "\n(ERREUR) La commande suivante a �chou�e :\n",
         "  $DEF{PKZIP} -m $DEF{OUTPUT}\\$DEF{BASENAME}.ZIP $DEF{OUTPUT}\\$DEF{BASENAME}.EXE $DEF{OUTPUT}\\file_id.diz >nul\n";
  rename ("$DEF{OUTPUT}\\$DEF{BASENAME}.ZIP", "$DEF{OUTPUT}\\$DEF{BASENAME}.ZIP") == 1
      or die "\n(ERREUR) La commande suivante a �chou�e :\n",
         "  ren $DEF{OUTPUT}\\$DEF{BASENAME}.ZIP $DEF{OUTPUT}\\$DEF{BASENAME}.ZIP";
}

############
# message de fin
#
sub msg_fin
{
  print "\nLe package $DEF{OUTPUT}\\$DEF{BASENAME}.ZIP est termin� !\n\n";
}

############
# message de fin avec erreur
#
sub msg_err
{
  print "\nLe package n'est pas termin� !\n";
}

############
# Programme principal
#
{

  # affiche les infos du programme
  print "MicroBest Small Installation Packager version 2.0\n";
  print "(c) William BLUM 1998-1999\n\n";
  
  # Obtient la date syst�me et stocke l� dans les cl�es 'SHORT_DATE' et 'LONG_DATE'
  ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
  $DEF{SHORT_DATE} = ($mon+1)."/$mday/".(1900+$year);
  $DEF{LONG_DATE} = localtime;  

  $param = pop(@ARGV);

  # lecture du script de packaging
  lit_build_script($param) or goto err;


  # cr�e le r�pertoire temporaire et le r�pertoire destination
  mkdir('sip.tmp',777);
  mkdir($DEF{OUTPUT},777);
  
  # g�n�re la liste des fichiers � installer et copie ces fichiers dans un r�pertoire temporaire
  gen_liste_fichiers();

  # g�n�re la liste des raccourcis
  gen_liste_raccourcis();

  # g�n�re le fichier script d'installation (INF) et copie l'arborescence
  gen_setup_inf();

  # g�n�ration du script (SETUP.SED) utilis� par IExpress pour cr�er le programme d'installation (SETUP.EXE)
  gen_iexpress_sed();

  # g�n�ration du programme d'installation (SETUP.EXE)
  gen_setup_exe();

  # g�n�ration du fichier d'information (FILE_ID.DIZ)
  gen_file_id();

  # compression des fichier finaux (SETUP.EXE+FILE_ID.DIZ -> APP.ZIP)
  compression_finale();

  # d�truit le r�pertoire temporaire et le fihier file_id.diz
  unlink <sip.tmp\\*.*>;  rmdir 'sip.tmp';
  unlink "$DEF{OUTPUT}\\file_id.diz";

  # message de fin
  msg_fin();


  goto fin;

err:
  msg_err();

fin:
}
