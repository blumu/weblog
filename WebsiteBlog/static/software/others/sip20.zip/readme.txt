Small Installation Packager 2.0 (SIP)
=====================================

Small Installation Packager is a freeware. You can distribute it freely.


INSTALLATION
============

1 This program is a perl Script. To run it, you need to install a Perl language interpreter in your computer.

 * At the adress below, you can download a program called "Active Perl" which can be used freely.

  http://www.ActiveState.com/ActivePerl/

  * You can use too the Microsoft implementation of Perl which can be found in the "Microsoft NT Resource Kit"
    (downloadable on  their site: http://www.microsoft.com/ ).

2 You need also to install "iexpress wizard". (can be found on ms visual studio cds).

3 You can optionnaly install "pkzip".

4 Unzip the SIP package into a directory


HOW TO RUN ZIP
==============

The command line is 

   SIP.BAT sip_script_file_name


DOCUMENTATION
=============

Currently, there isn't any documentation. But it's easy to learn how it works by looking at examples.



CONTACT
=======

William BLUM

adress:  14, rue du VALLON
         25220 THISE
         FRANCE

email:   wblum@multimania.com

web:     http://www.multimania.com/wblum/

